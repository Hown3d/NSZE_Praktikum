package com.example.praktikum2.ui.Interfaces;

import android.view.View;

public interface FragmentSearchListener {
    void Onsearchclicked(View v);
}
